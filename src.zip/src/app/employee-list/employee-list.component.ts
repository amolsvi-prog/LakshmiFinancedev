import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/employee';
import { CommonService } from '../shared/common.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
employeeList:Employee[];
  constructor(private _common:CommonService) { }

  ngOnInit(): void {
    this._common.getAllData().subscribe((empList)=>{
this.employeeList=empList;
    })

// this._common.getAllData().subscribe(this.myList)
  }

//   myList(list) {
//    this.employeeList=list;
//  }


}
