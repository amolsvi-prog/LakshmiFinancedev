import { Component } from '@angular/core';
import { AppModule } from './app.module';
import { CommonService } from './shared/common.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
    constructor() { 
       
  }

  ngOnInit(): void {
      
  }
  }


