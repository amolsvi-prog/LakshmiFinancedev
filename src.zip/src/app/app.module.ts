import { NgModule } from '@angular/core';
import { FormsModule, NgModel, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//import { DemoModule } from './demo/demo.module';
import { CommonService } from './shared/common.service';
import {HttpClientModule} from '@angular/common/http';
import { EmployeeListComponent } from './employee-list/employee-list.component';
console.log("module.......loaded");
@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    
      ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
    
     ],
  providers: [
    CommonService  ],
 
  
  bootstrap: [AppComponent],
 
})
export class AppModule { }
