import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
empUrl:string="http://localhost:3000/Employee";
  
  constructor( private _http:HttpClient) { }

  getAllData():Observable<Employee[]>
  {
 return this._http.get<Employee[]>(this.empUrl);
  }
}
