export class Employee {
    id:number;
    name:string;
    address:string;
    mblno:string;
    username:string;
    password:string;
}
